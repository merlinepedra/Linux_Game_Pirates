# Archiving and compression
- Here are some methods of distributing files.
```sh
zstd [Source File] --ultra -22 -o [Outputfile.zst]
```