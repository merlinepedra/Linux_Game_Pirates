# BeginnerInfo  

This directory is for providing basic information about Linux Piracy.

- [Distros and Libraries](http://www.it7otdanqu7ktntxzm427cba6i53w6wlanlh23v5i3siqmos47pzhvyd.onion/johncena141/Linux_Game_Pirates/src/branch/master/BeginnerInfo/Distros_and_libraries.md)
- [Using Lutris](http://www.it7otdanqu7ktntxzm427cba6i53w6wlanlh23v5i3siqmos47pzhvyd.onion/johncena141/Linux_Game_Pirates/src/branch/master/BeginnerInfo/Using_lutris.md)