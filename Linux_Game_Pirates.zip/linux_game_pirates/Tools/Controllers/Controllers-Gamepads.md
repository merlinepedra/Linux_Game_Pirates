Check your if your controller is working

	1) Run Wine File Manager
	2) Go to Control Panel
	3) Click on Game Controllers

	Here you can test, enable or disable the available Controllers (Joysticks) inside wine.

<img src="controller-test.png">

Controller keyboard mapping

antimicroX
https://github.com/juliagoda/antimicroX

----------------------------------------------------------------------------------------------------------
## Contributors:

- bon-bon