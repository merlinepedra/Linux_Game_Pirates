### PirateDB
Compatibility information for game piracy on Linux.<br>

- [Gold Rated Games / Flawless](http://www.it7otdanqu7ktntxzm427cba6i53w6wlanlh23v5i3siqmos47pzhvyd.onion/johncena141/Linux_Game_Pirates/src/branch/master/PirateDB/Games/1.Gold_Rating.md)
- [Silver Rated Games / Minor tweaks](http://www.it7otdanqu7ktntxzm427cba6i53w6wlanlh23v5i3siqmos47pzhvyd.onion/johncena141/Linux_Game_Pirates/src/branch/master/PirateDB/Games/2.Silver_Rating.md)
- [Bronze Rated Games / Requires modifications](http://www.it7otdanqu7ktntxzm427cba6i53w6wlanlh23v5i3siqmos47pzhvyd.onion/johncena141/Linux_Game_Pirates/src/branch/master/PirateDB/Games/3.Bronze_Rating.md)
 - [Borked Rated Games / Not working](http://www.it7otdanqu7ktntxzm427cba6i53w6wlanlh23v5i3siqmos47pzhvyd.onion/johncena141/Linux_Game_Pirates/src/branch/master/PirateDB/Games/4.Borked_Rating.md)
 - [Crack Scene](http://www.it7otdanqu7ktntxzm427cba6i53w6wlanlh23v5i3siqmos47pzhvyd.onion/johncena141/Linux_Game_Pirates/src/branch/master/PirateDB/Crack_Scene.md)
- [Repackers](http://www.it7otdanqu7ktntxzm427cba6i53w6wlanlh23v5i3siqmos47pzhvyd.onion/johncena141/Linux_Game_Pirates/src/branch/master/PirateDB/Repackers.md)