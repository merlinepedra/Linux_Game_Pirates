# PirateDB - Repackers
Compatibility information for pirated games on Linux, be it Native or through Wine.
<br><br>

### Fitgirl's Repacks

- [Run with script](https://github.com/Francesco149/protonfit) created by Francesco149.

- Modifications got upstreamed to Wine 5.17, you can install vcrun2015 and vcrun2017 instead of using the script above.

- Even if wine compatility improves, the usage us freearc compression will always be unstable and we can't guarantee your bandwidth won't be wasted.
<br>

### DODI's Repacks

- No tests were made after 5.17 update of Wine which fixed Fitgirl's Installer at least.

- Installing vcrun2015 or vcrun2017 is still recommended.

- Works like Fitgirl, freearc usage.

### Darck Repacks

- Working fine. Tested on 5.17

### IGGGAMES

- As far as compatibility goes, it's working fine. They have a pretty bad reputation though.
----------------------------------------------------------------------------------------------------------
## Contributors:

- johncena141, ah_86